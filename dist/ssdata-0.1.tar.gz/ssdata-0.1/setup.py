from setuptools import setup
setup(name='ssdata',
      version='0.1',
      description='test',
      url='http://github.com/tongling/clinicaltrial',
      author='zejin',
      author_email='ginynu@gmail.com',
      license='MIT',
      packages=['ssdata',],
      zip_safe=False)
